package com.memship.biz.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.memship.biz.service.MemshipBarcodeService;
import com.memship.biz.service.MemshipPointService;
import com.memship.biz.vo.request.MemshipBarcodeRequest;
import com.memship.biz.vo.request.MemshipPointListRequest;
import com.memship.biz.vo.request.MemshipPointRequest;
import com.memship.biz.vo.response.MemshipBarcodeResponse;
import com.memship.biz.vo.response.MemshipPointListResponse;
import com.memship.biz.vo.response.MemshipPointResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.tags.Tags;


/**
 * api controller.
 * RestAPI Controller.
 */
@RestController
@RequestMapping("/v1/memship")
@Tags(@Tag(name = "Membership 서비스", description = "멤버십 바코드 API"))
public class MemshipApiController {

    private final MemshipBarcodeService memshipBarcodeService;
    private final MemshipPointService memshipPointService;
    


    /**
     * Instantiates a new api controller.
     *
     */
    @Autowired
    public MemshipApiController(
            MemshipBarcodeService memshipBarcodeService
            , MemshipPointService memshipPointService) {
        this.memshipBarcodeService = memshipBarcodeService;
		this.memshipPointService = memshipPointService;
    }

    /**
     * 통합바코드 발급 API.
     *
     * @param request the request
     * @return the issue response
     */
    @PostMapping("/new")
    @ApiOperation(
            value = "통합 바코드 발급 API", tags = "Membership 서비스",
            notes = "사용자 ID, 바코드 NO, 발급시간을 기록하여 바코드를 생성")
    public MemshipBarcodeResponse memshipBarcodeIssue(@RequestBody MemshipBarcodeRequest request) {
    	return memshipBarcodeService.memshipBarcode(request);
    }
    
    /**
     * 포인트 적립 API
     *
     * @param request the request
     * @return the earn point response
     */
    @PostMapping("/earn")
    @ApiOperation(
            value = "포인트 적립 API", tags = "Membership 서비스",
            notes = "요청값은 상점 id, 발급한 바코드, 적립금, 포인트 적립은 상점의 업종별로 통합하여 적립")
    public MemshipPointResponse memshipPointEarn(@RequestBody MemshipPointRequest request) {
    	return memshipPointService.memshipPointEarn(request);
    }

    /**
     * 포인트 사용 API
     * 
     * @param request the request
     * @return the use point response
     */
    @PostMapping("/use")
    @ApiOperation(
            value = "포인트 사용 API", tags = "Membership 서비스",
            notes = "요청값은 상점 id, 발급한 바코드, 사용금액, 포인트 사용은 요청한 상점의 업종별 통합 적립금에서 사용")
    public MemshipPointResponse memshipPointUse(@RequestBody MemshipPointRequest request) {
    	return memshipPointService.memshipPointUse(request);
    }
    
    /**
     * 내역 조회 API
     *
     * @param request the request
     * @return the point list response
     */
    @PostMapping("/history")
    @ApiOperation(
            value = "포인트 내역조회 API", tags = "Membership 서비스",
            notes = "요청값은 시작기간, 종료기간, 멤버십 바코드, 응답값에는 사용시기, 구분(적립,사용), 상점명, 업종정보")
    public MemshipPointListResponse memshipPointList(@RequestBody MemshipPointListRequest request) {
    	return memshipPointService.memshipPointList(request);
    }
    
}
