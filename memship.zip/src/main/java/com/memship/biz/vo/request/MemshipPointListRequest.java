package com.memship.biz.vo.request;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.memship.common.code.MemshipPointTypeCode;
import com.memship.common.web.vo.request.CommonRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type request.
 *
 * @author
 * @since
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="[포인트 히스토리] - 요청", description="[포인트 히스토리] API request 입니다.")
public class MemshipPointListRequest extends CommonRequest {

    @NotBlank
    @Length(min = 10 , max = 10)
    @ApiModelProperty(value="바코드", example = "7714462582", required = true)
    private String barcodeNo;
    
    @ApiModelProperty(value="시작일자", example = "20221201", required = true)
    private String startAt;

    @ApiModelProperty(value="종료일자", example = "20221231", required = true)
    private String endAt;
}
