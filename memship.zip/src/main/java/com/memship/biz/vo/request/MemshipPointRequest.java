package com.memship.biz.vo.request;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.memship.common.code.MemshipPointTypeCode;
import com.memship.common.web.vo.request.CommonRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type request.
 *
 * @author
 * @since
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="[포인트 적립 사용] - 요청", description="[포인트 적립과 사용] API Request 입니다.")
public class MemshipPointRequest extends CommonRequest {
   
    @NotBlank
    @Length(min = 1 , max = 10)
    @ApiModelProperty(value="상점id", example = "F", required = true)
    private String partner;
    
    @NotBlank
    @Length(min = 10 , max = 10)
    @ApiModelProperty(value="바코드", example = "7714462582", required = true)
    private String barcodeNo;

    @Length(min = 1 , max = 9)
    @ApiModelProperty(value="포인트금액", example = "1000", required = true)
    private int pointAmt;
}
