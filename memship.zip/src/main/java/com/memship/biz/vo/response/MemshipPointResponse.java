package com.memship.biz.vo.response;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.memship.common.code.MemshipPointTypeCode;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The type Invest response.
 *
 * @author 
 * @since 
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ApiModel(value="[포인트 적립 사용] - 응답", description="[포인트 적립 사용] API Response 입니다.")
public class MemshipPointResponse {

    @NotBlank
    @Length(min = 1 , max = 20)
    @ApiModelProperty(value="상점id", example = "F", required = true)
    private String partner;
    
    @NotBlank
    @Length(min = 1 , max = 10)
    @ApiModelProperty(value="바코드", example = "1234567890", required = true)
    private String barcodeNo;

    @Length(min = 1 , max = 9)
    @ApiModelProperty(value="포인트금액", example = "1000", required = true)
    private int pointAmt;

    @ApiModelProperty(value="구분(적립:earn, 사용:use) ")
    private MemshipPointTypeCode typeCd;
}