package com.memship.biz.vo.request;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.memship.common.code.MemshipPointTypeCode;
import com.memship.common.web.vo.request.CommonRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type request.
 *
 * @author
 * @since
 */
@Data
@Builder
@EqualsAndHashCode(callSuper = true)
@ApiModel(value="[멤버십 발행] - 요청", description="[멤버십 발행] API Request 입니다.")
public class MemshipBarcodeRequest extends CommonRequest {

}
