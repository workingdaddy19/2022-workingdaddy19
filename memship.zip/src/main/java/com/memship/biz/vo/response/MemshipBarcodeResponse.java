package com.memship.biz.vo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The type Invest response.
 *
 * @author 
 * @since 
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ApiModel(value="[멤버십 발행] - 응답", description="[멤버십 발행] API Response 입니다.")
public class MemshipBarcodeResponse {

    @ApiModelProperty(value="사용자ID")
    private long userId;
    @ApiModelProperty(value="바코드NO")
    private String barcodeNo;
}
