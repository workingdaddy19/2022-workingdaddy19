package com.memship.biz.vo.response;

import java.util.List;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.memship.biz.service.dto.MemshipPointDTO;
import com.memship.common.code.MemshipPointTypeCode;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The type Invest response.
 *
 * @author 
 * @since 
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ApiModel(value="[포인트 히스토리] - 응답", description="[포인트 히스토리] API Response 입니다.")
public class MemshipPointListResponse {

    @ApiModelProperty(value="포인트조회목록수", example = "")
    private int pointCnt;

    @ApiModelProperty(value="멤버십포인트목록", example = "")
    private List<memshipPoint> memshipPointList;


    /**
     * The type Invest transaction.
     */
    @NoArgsConstructor
    @AllArgsConstructor
    @Getter
    @Builder
    @ApiModel(value="[포인트 히스토리 상세] - 응답", description="[포인트 리스트 상세] API Response 입니다.")
    public static class memshipPoint{
        @ApiModelProperty(value="사용시기", example = "123456789")
        private String approvedAt;
        
        @ApiModelProperty(value="구분(적립:earn, 사용:use) ")
        private MemshipPointTypeCode typeCd;
        
        @ApiModelProperty(value="상점명", example = "F마트")
        private String partnerNm;
        
        @ApiModelProperty(value="업종정보", example = "식품")
        private String categoryNm;

        @ApiModelProperty(value="포인트금액", example = "1000")
        private int pointAmt;
        
        @ApiModelProperty(value="바코드", example = "123456789")
        private String barcodeNo;
        
    }
}
