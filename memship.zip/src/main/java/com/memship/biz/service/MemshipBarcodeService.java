package com.memship.biz.service;

import org.springframework.transaction.annotation.Transactional;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.vo.request.MemshipBarcodeRequest;
import com.memship.biz.vo.response.MemshipBarcodeResponse;

/**
 * barcode service.
 * 
 */
public interface MemshipBarcodeService {

    /**
     * 통합 멤버십 바코드를 생성하는 서비스 
     */
    @Transactional
    MemshipBarcodeResponse memshipBarcode(MemshipBarcodeRequest request);
}
