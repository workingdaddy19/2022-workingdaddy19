package com.memship.biz.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.memship.biz.service.dto.MemshipPointDTO;

/**
 * The interface mapper.
 *
 * @author happypapa
 * @since 
 */
@Mapper
@Repository
public interface MemshipPointMapper {

    /**
     * 신규 바코드 등록
     */
    void insertMemshipPoint(MemshipPointDTO memshipPointDTO);
    
    /**
    * 포인트 내역조회
    */
    List<MemshipPointDTO> selectMemshipPointList(MemshipPointDTO memshipPointDTO);

    /**
    * 포인트 사용직전 잔액조회
    */
    MemshipPointDTO selectPointAmtBal(MemshipPointDTO memshipPointDTO);

}
