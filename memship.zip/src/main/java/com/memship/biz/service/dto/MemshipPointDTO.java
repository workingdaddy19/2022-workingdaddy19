package com.memship.biz.service.dto;

import com.memship.common.code.MemshipPointTypeCode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The type memshipoint dto.
 *
 * @author happypapa
 * @since 
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class MemshipPointDTO {

    private String transactionId;           /* 트랜젝션 */
    private String barcodeNo;               /* 바코드 */
    private String partner;                 /* 가맹점코드 */
    private String partnerNm;               /* 가맹점명 */
    private String category;                /* 업종유형코드 */
    private String categoryNm;              /* 업종유형명 */
    private String approvedAt;              /* 사용시기 */
    private MemshipPointTypeCode typeCd;     /* 사용구분 0:earn, 1:use*/
    private int pointAmt;                   /* 포인트금액 */

    private long userId ;
    private int pointAmtBal;                /* 개인별 잔액 */
    
    private int cnt;                		/* valid 카운트*/

    /* 포인트 내역 조회 기간*/
    private String startAt;                 /* 시작기간 */
    private String endAt;                   /* 종료기간 */ 
}
