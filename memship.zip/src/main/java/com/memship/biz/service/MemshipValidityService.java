package com.memship.biz.service;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.service.dto.MemshipPointDTO;

/**
 * The interface validity service.
 *
 * @author 
 * @since 
 */
public interface MemshipValidityService {

    /**
     * validity response.
     *
     * @param request the request
     * @return response
     */

	MemshipBarcodeDTO barcodeUserService(MemshipBarcodeDTO request);
    
	MemshipBarcodeDTO barcodeValidityService(MemshipBarcodeDTO request);

	MemshipPointDTO partnerValidityService(MemshipPointDTO request);

}
