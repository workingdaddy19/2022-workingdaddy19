package com.memship.biz.service.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.service.dto.MemshipPointDTO;

/**
 *
 * @author
 * @since 
 */
@Mapper
@Repository
public interface MemshipValidityMapper {

    /**
     * @param condition the condition
     * @return 
     */
	MemshipBarcodeDTO selectMemshipUserChk(MemshipBarcodeDTO condition);

	MemshipBarcodeDTO selectMemshipBarcodeChk(MemshipBarcodeDTO condition);
	
	MemshipPointDTO selectMemshipPartnerChk(MemshipPointDTO condition);
}
