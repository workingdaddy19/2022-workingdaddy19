package com.memship.biz.service;

import org.springframework.transaction.annotation.Transactional;

import com.memship.biz.vo.request.MemshipPointListRequest;
import com.memship.biz.vo.request.MemshipPointRequest;
import com.memship.biz.vo.response.MemshipPointListResponse;
import com.memship.biz.vo.response.MemshipPointResponse;

/**
 * 멤버십포인트 사용과 적립 서비스
 */
public interface MemshipPointService {


    @Transactional
    MemshipPointResponse memshipPointEarn(MemshipPointRequest request);

    @Transactional
    MemshipPointResponse memshipPointUse(MemshipPointRequest request);
    

    MemshipPointListResponse memshipPointList(MemshipPointListRequest request);
}
