package com.memship.biz.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.service.dto.MemshipPointDTO;
import com.memship.biz.service.mapper.MemshipPointMapper;
import com.memship.biz.vo.request.MemshipPointListRequest;
import com.memship.biz.vo.request.MemshipPointRequest;
import com.memship.biz.vo.response.MemshipPointListResponse;
import com.memship.biz.vo.response.MemshipPointResponse;
import com.memship.common.code.ResponseCode;
import com.memship.common.code.MemshipPointTypeCode;
import com.memship.framework.exception.ServiceException;

/**
 * The type memship point service.
 *
 * @author happypapa
 */
@Validated
@Service
public class MemshipPointServiceImpl implements MemshipPointService {

    private final MemshipPointMapper memshipPointMapper;
    private final MemshipValidityService memshipValidityService;

    /** MemshipPointService
     * 멤버십 포인트 적립과 사용 (memshipPointEarn, memshipPointUse)
     * 포인트 적립/사용 내역 조회 (memshipPointList)
     */
    public MemshipPointServiceImpl( 
            MemshipPointMapper memshipPointMapper
           ,MemshipValidityService memshipValidityService
    ) {
        this.memshipPointMapper = memshipPointMapper;
		this.memshipValidityService = memshipValidityService;
    }


    public void MemshipBarcodeChk(MemshipPointListRequest request) {
	    /*======================================================================================
	     * 바코드 유효성 체크
	    ======================================================================================*/
    	MemshipBarcodeDTO barcode_response = memshipValidityService.barcodeValidityService(MemshipBarcodeDTO.builder()
	            .userId(request.getUserId())
	            .barcodeNo(request.getBarcodeNo())
	            .build());
		if(barcode_response.getCnt()==0) {
	        // 멤버십에 미등록된 바코드입니다. 바코드 : [%s]
	        throw new ServiceException(ResponseCode.BARCODE_NON_EXIST, request.getBarcodeNo());
		}
    }
    
    public void MemshipBarcodeChk(MemshipPointRequest request) {
	    /*======================================================================================
	     * 바코드 유효성 체크
	    ======================================================================================*/
    	MemshipBarcodeDTO barcode_response = memshipValidityService.barcodeValidityService(MemshipBarcodeDTO.builder()
	            .userId(request.getUserId())
	            .barcodeNo(request.getBarcodeNo())
	            .build());
		if(barcode_response.getCnt()==0) {
	        // 멤버십에 미등록된 바코드입니다. 바코드 : [%s]
	        throw new ServiceException(ResponseCode.BARCODE_NON_EXIST, request.getBarcodeNo());
		}
    }
    
    public void MemshipPartnerChk(MemshipPointRequest request) {
	    /*======================================================================================
	     * 가맹점 유효성 체크
	    ======================================================================================*/
    	MemshipPointDTO partner_response = memshipValidityService.partnerValidityService(MemshipPointDTO.builder()
	            .partner(request.getPartner())
	            .build());
		if(partner_response.getCnt()==0) {
	        // 멤버십에 미등록된 가맹점입니다. 가맹점코드 : [%s]
	        throw new ServiceException(ResponseCode.PARTNER_NON_EXIST, request.getPartner());
		}
    }
	 /**
     * 멤버십 포인트 적립 (memshipPointEarn)
     */
    @Override
    public MemshipPointResponse memshipPointEarn(MemshipPointRequest request) {    	
    	//입력 바코드와 가맹점 유효성 체크
    	MemshipBarcodeChk(request);
    	MemshipPartnerChk(request);
        /*======================================================================================
         * 포인트 적립 등록
        ======================================================================================*/
    	memshipPointMapper.insertMemshipPoint(MemshipPointDTO.builder()
                .barcodeNo(request.getBarcodeNo())
                .partner(request.getPartner())
                .typeCd(MemshipPointTypeCode.EARN)
                .pointAmt(request.getPointAmt())
                .build());
        return MemshipPointResponse.builder()
                .barcodeNo(request.getBarcodeNo())
                .partner(request.getPartner())
                .typeCd(MemshipPointTypeCode.EARN)
                .pointAmt(request.getPointAmt())
                .build();
    }
	 /** 
     * 멤버십 포인트 사용  (memshipPointUse)
     */
	@Override
    public MemshipPointResponse memshipPointUse(MemshipPointRequest request) {
    	//입력 바코드와 상점 유효성 체크
    	MemshipBarcodeChk(request);
    	MemshipPartnerChk(request);
        /*======================================================================================
         * 1) 사용전 잔액 확인
        ======================================================================================*/
    	MemshipPointDTO pointBalance = memshipPointMapper.selectPointAmtBal(MemshipPointDTO.builder()
                .userId(request.getUserId())
                .partner(request.getPartner())
                .build());
    	if(request.getPointAmt() > pointBalance.getPointAmtBal()) {
            // 포인트가 부족합니다. 업종정보: [%s], 포인트 잔액: [%s]"
            throw new ServiceException(ResponseCode.POINT_NOT_ENOUGH, pointBalance.getCategoryNm(), pointBalance.getPointAmtBal());
    	}

        /*======================================================================================
         * 2) 포인트 사용
        ======================================================================================*/
    	memshipPointMapper.insertMemshipPoint(MemshipPointDTO.builder()
                .barcodeNo(request.getBarcodeNo())
                .partner(request.getPartner())
                .typeCd(MemshipPointTypeCode.USE)
                .pointAmt(request.getPointAmt())
                .build());

        return MemshipPointResponse.builder()
                        .barcodeNo(request.getBarcodeNo())
                        .partner(request.getPartner())
                        .typeCd(MemshipPointTypeCode.USE)
                        .pointAmt(request.getPointAmt())
                        .build();
    }
	
	 /**
     * 포인트 적립,사용 내역 조회 (memshipPointList)
     */
	@Override
	public MemshipPointListResponse memshipPointList(MemshipPointListRequest request) {
    	//입력 바코드와 유효성 체크
    	MemshipBarcodeChk(request);
    	
    	List<MemshipPointDTO> memshipPointList = 
		memshipPointMapper.selectMemshipPointList(MemshipPointDTO.builder()
                .barcodeNo(request.getBarcodeNo())
				.startAt(request.getStartAt())
				.endAt(request.getEndAt())
				.build());
    	
    	return MemshipPointListResponse.builder()
                .pointCnt(memshipPointList.size())
    			.memshipPointList(memshipPointList.stream()
    					.map(point -> MemshipPointListResponse.memshipPoint.builder()
    							.approvedAt(point.getApprovedAt())
    							.barcodeNo(point.getBarcodeNo())
    							.categoryNm(point.getCategoryNm())
    							.partnerNm(point.getPartnerNm())
    							.typeCd(point.getTypeCd())
    							.pointAmt(point.getPointAmt())
    							.build())
    					.collect(Collectors.toList())).build();
	}
}