package com.memship.biz.service;

import java.util.Random;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.service.mapper.MemshipBarcodeMapper;
import com.memship.biz.vo.request.MemshipBarcodeRequest;
import com.memship.biz.vo.response.MemshipBarcodeResponse;
import com.memship.common.code.ResponseCode;
import com.memship.framework.exception.ServiceException;

/**
 * The type service.
 *
 * @author 
 * @since
 */
@Validated
@Service
public class MemshipBarcodeServiceImpl implements MemshipBarcodeService {

	private final MemshipBarcodeMapper memshipBarcodeMapper;
    private final MemshipValidityService barcodeValidityService;

    /** 
     * MemshipBarcodeService
     * 1. 통합 바코드 발급 API
     *  1) 기 멤버십회원 체크
     *  2) 신규 난수로 기존 바코드 중복여부 체크
     *  3) 신규 멤버십 바코드 생성
     */
    public MemshipBarcodeServiceImpl( 
            MemshipValidityService barcodeValidityService
           ,MemshipBarcodeMapper memshipBarcodeMapper
    ) {
		this.barcodeValidityService = barcodeValidityService;
        this.memshipBarcodeMapper = memshipBarcodeMapper;
    }

    /** 
     * barcode_maker(int length) : 바코드 난수생성기
     * @return resultNum
     */
    public String barcode_maker(int lengthNum) {
	 	Random random = new Random();	//랜덤 함수 선언
		int createNum = 0;  			//1자리 난수
		String ranNum = ""; 			//1자리 난수 형변환 변수
	    int letter    = 10;				//난수 자릿수:10
		String resultNum = "";  		//결과 난수	
		for (int i=0; i<letter; i++) { 
	        		
			createNum = random.nextInt(lengthNum);	//0부터 9까지 올 수 있는 1자리 난수 생성
			ranNum =  Integer.toString(createNum);  //1자리 난수를 String으로 형변환
			resultNum += ranNum;			//생성된 난수(문자열)을 원하는 수(letter)만큼 더하며 나열
		}			    
	    return resultNum;
    }
    /** 
     * memshipBarcode : 통합 바코드 발급
     * @return 
     */
    @Override
    public MemshipBarcodeResponse memshipBarcode(MemshipBarcodeRequest request) {
        /*======================================================================================
         * 1) 기 바코드 보유자 인지 확인
        ======================================================================================*/
    	boolean barcode_bool = true;
    	String barcode_no = null;
    	
    	MemshipBarcodeDTO barcode_response = barcodeValidityService.barcodeUserService(MemshipBarcodeDTO.builder()
                .userId(request.getUserId())
                .build());

    	if (barcode_response != null) { // 이미 존재하는 회원의 경우
	        if (barcode_response.getCnt() > 0) {
                // 이미 바코드가 등록된 회원입니다. 바코드 : [%s]
	            throw new ServiceException(ResponseCode.BARCODE_EXIST, barcode_response.getBarcodeNo());
	        }   
    	}
        /*======================================================================================
         * 2) 바코드 번호 채번 후 중복체크 (반복)
        ======================================================================================*/
    	while(barcode_bool) {
    		barcode_no = barcode_maker(10);
    		barcode_response = barcodeValidityService.barcodeValidityService(MemshipBarcodeDTO.builder()
	                .barcodeNo(barcode_no)
	                .userId(request.getUserId())
	                .build());
	    	if(barcode_response.getCnt()==0)
	    		barcode_bool=false;
    	}
        /*======================================================================================
         * 3) 신규 바코드로 유저 생성
        ======================================================================================*/
    	memshipBarcodeMapper.insertBarcode(MemshipBarcodeDTO.builder()
                .barcodeNo(barcode_no)
                .userId(request.getUserId())
                .build());
    	
		return MemshipBarcodeResponse.builder()
                .barcodeNo(barcode_no)
                .userId(request.getUserId())
				.build();
    }
}
