package com.memship.biz.service.dto;

import com.memship.common.code.MemshipPointTypeCode;

import lombok.*;

/**
 * The type dto.
 *
 * @author 
 * @since 
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class MemshipBarcodeDTO {

    private String barcodeNo;                 /* 바코드 */
    private long userId ;
    private int cnt ;
    private String partner;                   /* 가맹점 */
}
