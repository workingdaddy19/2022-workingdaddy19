package com.memship.biz.service;

import org.springframework.stereotype.Service;

import com.memship.biz.service.dto.MemshipBarcodeDTO;
import com.memship.biz.service.dto.MemshipPointDTO;
import com.memship.biz.service.mapper.MemshipValidityMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * The validity service.
 * @author happypapa
 */
@Slf4j
@Service
public class MemshipValidityServiceImpl implements MemshipValidityService {

    private final MemshipValidityMapper memshipValidityMapper;

    public MemshipValidityServiceImpl(
    		MemshipValidityMapper memshipValidityMapper
    ) {
        this.memshipValidityMapper = memshipValidityMapper;
    }

	@Override
	public MemshipBarcodeDTO barcodeUserService(MemshipBarcodeDTO request) {
        return memshipValidityMapper.selectMemshipUserChk(request);
	}
	
	@Override
	public MemshipBarcodeDTO barcodeValidityService(MemshipBarcodeDTO request) {
        return memshipValidityMapper.selectMemshipBarcodeChk(request);
	}

	@Override
	public MemshipPointDTO partnerValidityService(MemshipPointDTO request) {
        return memshipValidityMapper.selectMemshipPartnerChk(request);
	}
}
