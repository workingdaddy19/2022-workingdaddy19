package com.memship.biz.service.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.memship.biz.service.dto.MemshipBarcodeDTO;

/**
 * The interface mapper.
 *
 * @author 
 * @since 
 */
@Mapper
@Repository
public interface MemshipBarcodeMapper {

    /**
     * Insert Barcode.
     * 바코드를 등록합니다.
     */
    void insertBarcode(MemshipBarcodeDTO memshipBarcodeDTO);

}
