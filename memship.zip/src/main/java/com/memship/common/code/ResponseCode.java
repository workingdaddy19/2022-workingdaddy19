package com.memship.common.code;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum ResponseCode {
    /*======================================================================================
     * 200
    ======================================================================================*/
    SUCCESS(HttpStatus.OK,                    true  ,"SUCCESS", "성공"),
    SUCCESS_CREATED(HttpStatus.CREATED,       true  ,"SUCCESS_CREATED", "등록성공"),

    /*======================================================================================
     * 400
    ======================================================================================*/

    BARCODE_EXIST(HttpStatus.CONFLICT,                  false ,"BARCODE_EXIST", "이미 바코드가 등록된 회원입니다. 바코드 : [%s]"),
    BARCODE_NON_EXIST(HttpStatus.CONFLICT,              false ,"BARCODE_NON_EXIST", "멤버십에 미등록된 바코드입니다. 바코드 : [%s]"),
    PARTNER_NON_EXIST(HttpStatus.CONFLICT,              false ,"PARTNER_NON_EXIST", "멤버십에 미등록된 가맹점입니다. 가맹점코드 : [%s]"),
    POINT_NOT_ENOUGH(HttpStatus.CONFLICT,               false ,"POINT_NOT_ENOUGH", "포인트가 부족합니다. 분류명: [%s], 포인트 잔액: [%s]"),
    
    MISSING_REQUIRED_PARAMETERS(HttpStatus.BAD_REQUEST, false ,"MISSING_REQUIRED_PARAMETERS","%s"),
    INVALID_HEADER(HttpStatus.BAD_REQUEST,              false ,"INVALID_HEADER", "header 필수 파라미터가 누락되었습니다. : [%s]"),
    INVALID_PARAMETER_TYPE(HttpStatus.BAD_REQUEST,      false ,"INVALID_PARAMETER_TYPE","파라미터 타입이 올바르지 않습니다. : [%s]"),
    INVALID_PARAMETER_RANGE(HttpStatus.BAD_REQUEST,     false ,"INVALID_PARAMETER_RANGE","[%s] 파라미터 값의 입력 범위는 [%s] 입니다."),
    INVALID_PARAMETER(HttpStatus.BAD_REQUEST,           false ,"INVALID_PARAMETER","파라미터 값이 올바르지 않습니다. : [%s]"),

    NOT_FOUND_API(HttpStatus.NOT_FOUND,                 false ,"NOT_FOUND_API", "요청한 엔드포인트는 존재하지 않음(일반적인 HTTP 404 에러)"),
    API_NOT_FOUND(HttpStatus.BAD_REQUEST,               false ,"API_NOT_FOUND","요청이 API가 요구하는 URL 혹은 HTTP 메서드와 다름"),
    INVALID_CONTENT_TYPE(HttpStatus.BAD_REQUEST,        false ,"INVALID_CONTENT_TYPE","	요청이 API가 요구하는 Content Type과 다름"),
    MISSING_PARAMETER(HttpStatus.BAD_REQUEST,           false ,"MISSING_PARAMETER","필요한 파라미터 값이 제공되지 않았음"),

    /*======================================================================================
     * 500
    ======================================================================================*/
    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,false , "INTERNAL_SERVER_ERROR", "시스템장애"),
    FAIL_REQUEST(HttpStatus.INTERNAL_SERVER_ERROR,false , "FAIL_REQUEST", "API 요청 처리 실패"),
    TIMEOUT(HttpStatus.INTERNAL_SERVER_ERROR,false , "TIMEOUT", "처리시간 초과 에러"),
    ;

    private HttpStatus httpStatus;
    private boolean success;
    private String code;
    private String message;

}
