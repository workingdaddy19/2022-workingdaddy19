package com.memship.common.code;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * MemshipPointTypeCode 
 * 포인트 적립/사용에 대한 구분값으로 활용
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum MemshipPointTypeCode implements EnumCode {

    EARN("0", "earn"),   //포인트 적립 0
    USE("1", "use");	   //포인트 사용 1

    private String key;
    private String value;
}
