package com.memship.common.constant;

/**
 * The type Api constant.
 *
 * @author happypapa
 * @since 
 */
public class ApiConstant {
    public static final String X_USER_ID = "x-user-id"; // 사용자 식별값
}
