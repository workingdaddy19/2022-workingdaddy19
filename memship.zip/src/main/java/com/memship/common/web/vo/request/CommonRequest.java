package com.memship.common.web.vo.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.validation.BindingResult;

/**
 * The type Common request.
 * 공통 요청 (모든 Request VO는 상속받아서 사용한다.)
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class CommonRequest {

    @JsonIgnore
    @ApiParam(value="사용자ID", example = "123456789", required = true)
    private long userId;
}
